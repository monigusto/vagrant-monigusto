0.0.10 (May 23, 2012)
---------------------

New features
* use autogen.sh to generate configure script for configure action
  https://github.com/bryanwb/chef-ark/issues/16
* support more file extensions https://github.com/bryanwb/chef-ark/pull/18
* add extension attribute which allows you to download files which do
  not have the file extension as part of the URL

Bug fixes
* strip_leading_dir not working for zip files
  https://github.com/bryanwb/chef-ark/issues/19

	
