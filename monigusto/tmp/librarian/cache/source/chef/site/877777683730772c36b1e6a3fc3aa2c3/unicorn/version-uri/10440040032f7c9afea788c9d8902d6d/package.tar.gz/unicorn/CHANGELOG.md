## v1.1.0:

* [COOK-857] - Unicorn not quoting listener ports/sockets
* [COOK-1273] - add ability to specify before_exec block

## v1.0.0:

* Current public release.
