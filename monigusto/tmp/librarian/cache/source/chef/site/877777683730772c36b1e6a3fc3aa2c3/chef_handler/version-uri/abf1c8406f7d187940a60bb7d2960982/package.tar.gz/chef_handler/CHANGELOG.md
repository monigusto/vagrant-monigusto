## v1.0.8:

* [COOK-1177] - doesn't work on windows due to use of unix specific attributes
## v1.0.6:

* [COOK-1069] - typo in chef_handler readme

## v1.0.4:

* [COOK-654] dont try and access a class before it has been loaded
* fix bad boolean check (if vs unless)

## v1.0.2:

* [COOK-620] ensure handler code is reloaded during daemonized chef runs
