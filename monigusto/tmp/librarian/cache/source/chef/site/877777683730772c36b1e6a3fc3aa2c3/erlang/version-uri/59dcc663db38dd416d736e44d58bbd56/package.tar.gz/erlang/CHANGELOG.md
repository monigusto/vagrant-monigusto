## v1.0.0:

* [COOK-905] - Fix installation on RHEL/CentOS 6+
