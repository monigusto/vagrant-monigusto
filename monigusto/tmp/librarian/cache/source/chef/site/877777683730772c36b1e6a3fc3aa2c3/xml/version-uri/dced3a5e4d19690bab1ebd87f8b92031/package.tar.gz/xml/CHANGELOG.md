## v1.0.4:

* [COOK-1232] - add xslt to xml cookbook

## v1.0.2:

* [COOK-953] - Add FreeBSD support
* [COOK-775] - Add Amazon Linux support

